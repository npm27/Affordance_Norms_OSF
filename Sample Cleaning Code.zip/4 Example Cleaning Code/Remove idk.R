
#get rid of the don't knows
dat$affordance_response[dat$affordance_response == "idk"] = NA
dat$affordance_response[dat$affordance_response == " idk"] = NA
dat$affordance_response[dat$affordance_response == "idk what this is"] = NA
dat$affordance_response[dat$affordance_response == "idk what that is"] = NA
dat$affordance_response[dat$affordance_response == "im sorry idk what this is either"] = NA
dat$affordance_response[dat$affordance_response == "idk what it is"] = NA
dat$affordance_response[dat$affordance_response == "idk its a person"] = NA
dat$affordance_response[dat$affordance_response == "don't know what that is"] = NA
dat$affordance_response[dat$affordance_response == "i don't know what that is"] = NA
dat$affordance_response[dat$affordance_response == "don't know what this is"] = NA
dat$affordance_response[dat$affordance_response == "i don't know what this is"] = NA
dat$affordance_response[dat$affordance_response == "i don't know"] = NA
dat$affordance_response[dat$affordance_response == "don't know"] = NA
dat$affordance_response[dat$affordance_response == "i don't know what a sawdust is"] = NA
dat$affordance_response[dat$affordance_response == "i don't know what this is "] = NA
dat$affordance_response[dat$affordance_response == "i don't know what a chronograph is"] = NA
dat$affordance_response[dat$affordance_response == "i don't know what it is"] = NA
dat$affordance_response[dat$affordance_response == "don't know word"] = NA
dat$affordance_response[dat$affordance_response == "i dont knwo"] = NA
dat$affordance_response[dat$affordance_response == "i dont know"] = NA
dat$affordance_response[dat$affordance_response == "i dont know what this means"] = NA
dat$affordance_response[dat$affordance_response == "i dont know what this is"] = NA
dat$affordance_response[dat$affordance_response == "i dont know what that is"] = NA
dat$affordance_response[dat$affordance_response == "dont know"] = NA
dat$affordance_response[dat$affordance_response == "dont know what that is"] = NA
dat$affordance_response[dat$affordance_response == "im not sure"] = NA
dat$affordance_response[dat$affordance_response == "i'm not sure"] = NA
dat$affordance_response[dat$affordance_response == "i'm not sure what this means"] = NA
dat$affordance_response[dat$affordance_response == "i'm not sure what this is"] = NA
dat$affordance_response[dat$affordance_response == "not sure"] = NA
dat$affordance_response[dat$affordance_response == "not sure what this is"] = NA
dat$affordance_response[dat$affordance_response == "i'm not sure "] = NA
dat$affordance_response[dat$affordance_response == "not sure what this is?? "] = NA
dat$affordance_response[dat$affordance_response == "	i am not sure what this is??"] = NA
dat$affordance_response[dat$affordance_response == "	im not sure what this is"] = NA
dat$affordance_response[dat$affordance_response == "	i'm not sure what this is "] = NA
dat$affordance_response[dat$affordance_response == "	not sure "] = NA
dat$affordance_response[dat$affordance_response == "i'm not sure what this is 	"] = NA
dat$affordance_response[dat$affordance_response == "	im not sure what this is"] = NA
dat$affordance_response[dat$affordance_response == "	not sure "] = NA
dat$affordance_response[dat$affordance_response == "not sure "] = NA
dat$affordance_response[dat$affordance_response == "i'm not sure what this is "] = NA
dat$affordance_response[dat$affordance_response == "	i dont know "] = NA
dat$affordance_response[dat$affordance_response == "i dont know "] = NA
dat$affordance_response[dat$affordance_response == "i dont know what this is,"] = NA
dat$affordance_response[dat$affordance_response == "i dont know what this is "] = NA
dat$affordance_response[dat$affordance_response == "idk "] = NA
dat$affordance_response[dat$affordance_response == "don't know what that is "] = NA
dat$affordance_response[dat$affordance_response == "i don't know what that is "] = NA
dat$affordance_response[dat$affordance_response == "don't know what a sawdust is"] = NA
dat$affordance_response[dat$affordance_response == "no idea"] = NA
dat$affordance_response[dat$affordance_response == "i have no idea"] = NA
dat$affordance_response[dat$affordance_response == "i have no idea what this is"] = NA
dat$affordance_response[dat$affordance_response == "no idea what that is"] = NA
dat$affordance_response[dat$affordance_response == "have no idea"] = NA
dat$affordance_response[dat$affordance_response == "no idea "] = NA
dat$affordance_response[dat$affordance_response == "no idea what this means"] = NA
dat$affordance_response[dat$affordance_response == "i have no idea what a terrace is "] = NA
dat$affordance_response[dat$affordance_response == "no clue"] = NA
dat$affordance_response[dat$affordance_response == "no clue "] = NA
dat$affordance_response[dat$affordance_response == "nothing"] = NA
dat$affordance_response[dat$affordance_response == "a game that i know nothing about"] = NA
dat$affordance_response[dat$affordance_response == "im not sure what this one is"] = NA
dat$affordance_response[dat$affordance_response == "im a carpenter"] = NA
dat$affordance_response[dat$affordance_response == "im not sure what this is"] = NA
dat$affordance_response[dat$affordance_response == "i am not sure what this is?? "] = NA
dat$affordance_response[dat$affordance_response == "?"] = NA
dat$affordance_response[dat$affordance_response == "ikd"] = NA
dat$affordance_response[dat$affordance_response == "lol"] = NA
dat$affordance_response[dat$affordance_response == "wtf is this"] = NA
dat$affordance_response[dat$affordance_response == "do't know"] = NA
